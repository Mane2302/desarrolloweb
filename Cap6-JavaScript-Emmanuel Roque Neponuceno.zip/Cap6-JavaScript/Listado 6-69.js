//Accediendo propiedades usando variables
var nombrePropiedad = "nombre";
var miobjeto = {
  nombre: "Emmanuel",
  edad: 22,
};
miobjeto.nombre = "Paco";
miobjeto.trabajo = "Programador";
alert(miobjeto.nombre + " " + miobjeto.edad + " " + miobjeto.trabajo);
