//Creando un objeto Date
var fecha = new Date();
alert(fecha);
