//Leyendo el mes
var hoy = new Date();
var ano = hoy.getFullYear();
var mes = hoy.getMonth() + 1;
var dia = hoy.getDate();
alert(ano + "-" + mes + "-" + dia);
