//Buscando un texto al comienzo de la cadena
var texto = "Hola mundo";
if (texto.startsWith("Ho")) {
    alert("El texto comineza con 'Ho'")
}