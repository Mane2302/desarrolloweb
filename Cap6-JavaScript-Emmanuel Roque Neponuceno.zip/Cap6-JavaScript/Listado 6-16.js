//Calculando el resto de una división
var minumero = 15 % 6;
alert(minumero); //3