//Iterando sobre los caracteres de una cadena
var texto = "Hola mundo";
var mensaje = "";
for (var f = 0; f < texto.length; f++) {
  mensaje += texto[f] + " ";
}
alert(mensaje);
