//Creando un objeto Date
var fecha = new Date("December 07 2023");
alert(fecha);
