//Creando un objeto Date
var fecha = new Date(2023, 11, 7, 20, 20, 20);
alert(fecha);
