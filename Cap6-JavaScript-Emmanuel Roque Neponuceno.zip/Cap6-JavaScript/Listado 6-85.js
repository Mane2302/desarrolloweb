//Realizando operaciones aritméticas con objetos
var valor = new Number("5");
var total = valor * 10;
alert(total);