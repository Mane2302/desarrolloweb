//Declarando el valor null
var miarray = [null, 9.75, undefined, 'Azul'];
alert(miarray[0]); //null