//Obteniendo un valor al azar
var numeroalazar = Math.random() * (21 - 10) + 10;
var valor = Math.floor(numeroalazar);
alert("El número es " + valor);