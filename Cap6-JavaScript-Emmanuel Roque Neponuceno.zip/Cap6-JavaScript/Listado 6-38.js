// Comprobando múltiples condiciones con operadores lógicos
var soltero = 'Si';
var edad = 18;
if (edad>=18 && soltero=='Si') {
  alert('El el solicitante puede casarse!!!')
}
else{
  alert('El solicitante no puede casarse')
}