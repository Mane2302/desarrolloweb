//Concatenando texto con números
var mitexto = 'El número es: ' + 5;
alert(mitexto);