//Incrementando el valor de una variable con valor específico
var minumero = 0;
minumero += 5;
alert(minumero); //5