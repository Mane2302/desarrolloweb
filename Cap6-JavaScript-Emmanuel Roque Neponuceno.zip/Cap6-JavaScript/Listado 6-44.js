//Creando un bucle con la instrucción for
var total = 0;
for (var f = 0; f < 5; f++) {
  total += 10;
}
alert("El total es: " + total);
