//Creando un array vacío con un constructor
var lista = new Array(2);
alert(lista[0] + " - " + lista[1]);
