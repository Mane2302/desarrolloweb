//Usando la instrucción do while
var contador = 150;
do {
  contador++;
} while (contador < 100);
alert("el valor es: " + contador);
