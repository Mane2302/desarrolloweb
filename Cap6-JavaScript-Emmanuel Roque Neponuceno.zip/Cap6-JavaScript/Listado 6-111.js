//Buscando múltiples valores en un array
var lista = [12, 5, 80, 34, 5, 6, 7];
lista.push(73);
alert(lista);