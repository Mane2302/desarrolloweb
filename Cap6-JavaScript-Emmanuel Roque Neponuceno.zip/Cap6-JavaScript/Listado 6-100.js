//Buscando un texto al comienzo de la cadena
var texto = "Hola mundo";
var palabra = texto.indexOf("mundo");
alert("La palabra comienza en el índice: " + palabra);