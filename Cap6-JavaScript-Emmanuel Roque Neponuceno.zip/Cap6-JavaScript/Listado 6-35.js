//Asignando un array vacío a una variable
var miarray = [1,2,3,4,5,6];
miarray = []
alert(miarray[1]); //undefined