// Usando números enteros como condiciones
var edad = 1;
if (edad) {
  alert('Tienes el permiso');
}