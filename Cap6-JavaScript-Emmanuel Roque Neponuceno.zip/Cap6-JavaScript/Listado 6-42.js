// Comprobando dos condiciones con if else
var minumero = 10;

if (minumero<10) {
  alert('El número es menor que 10')
} else {
  alert('El número es mayor o igual que 10')
}