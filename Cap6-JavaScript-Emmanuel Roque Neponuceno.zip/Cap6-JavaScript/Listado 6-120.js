//Eliminando valores de un array
var lista = [12, 5, 80, 34, 5, 6, 7];
var listanueva = lista.map(function (valor){
  return valor *2;
});
alert(listanueva);
