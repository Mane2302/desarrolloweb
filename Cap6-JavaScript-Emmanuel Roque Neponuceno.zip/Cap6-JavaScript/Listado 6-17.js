//Determinando la paridad de un número
var minumero = 3;
minumero = minumero % 2;
if (minumero==0) {
    alert('El número es par')
} else {
    alert('el numero es impar')
};