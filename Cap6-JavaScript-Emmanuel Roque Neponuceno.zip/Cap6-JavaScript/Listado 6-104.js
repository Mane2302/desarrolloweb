//Creando un array con los valores de otro array
var lista = [1, 2, 3, 4, 5];
var nuevalista = lista.slice(1, 3);
alert(nuevalista);
