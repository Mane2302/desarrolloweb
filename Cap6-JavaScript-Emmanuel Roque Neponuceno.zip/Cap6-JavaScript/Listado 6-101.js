//Buscando un texto al comienzo de la cadena
var texto = "Hola mundo";
var textonuevo = texto.replace("mundo", "Wapos");
alert(textonuevo);