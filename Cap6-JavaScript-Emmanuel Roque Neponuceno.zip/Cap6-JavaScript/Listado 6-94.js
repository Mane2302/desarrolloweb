//Copiando todos los caracteres desde un índice hasta el final de la cadena
var texto = "Hola mundo";
var palabra = texto.substring(5);
alert(palabra);
