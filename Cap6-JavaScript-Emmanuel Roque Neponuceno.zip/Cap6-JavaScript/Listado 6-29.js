//Declarando valores indefinidos
var miarray = ['Rojo', 9.75, undefined, 'Azul'];
alert(miarray[2]); // undefined