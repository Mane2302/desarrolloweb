//Mostrando todos los valores del array
var miarray = ['Rojo', 'Verde', 'Amarillo', 'Azul'];
alert(miarray); 