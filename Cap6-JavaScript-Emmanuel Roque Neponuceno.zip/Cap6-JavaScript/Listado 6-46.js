//Usando la instrucción while
var contador = 0;
while (contador<100) {
  contador++;
}
alert('El valor es: ' + contador); //100