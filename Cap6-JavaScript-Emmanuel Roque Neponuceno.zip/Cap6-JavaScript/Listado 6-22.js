//Concatenando números
var mitexto = '6' + 7;
alert(mitexto);