//Comprobando si un valor es un número o no
var mivalor = "Emmanuel";
var mivalor2 = 7;

if (isNaN(mivalor2)) {
  alert(mivalor2 + " no es un número");
} else {
  alert(mivalor2 + " es un número");
}
