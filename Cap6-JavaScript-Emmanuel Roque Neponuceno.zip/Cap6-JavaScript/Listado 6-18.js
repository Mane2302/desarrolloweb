//Asignando una cadena de caracteres a una variable
var mitexto = 'Hola mundo!!!';
alert(mitexto);