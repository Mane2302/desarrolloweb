//Ejecutando operaciones aritméticas con el objeto Math
var cuadrado = Math.sqrt(81);
var elevado = Math.pow(2, 3);
var maximo = Math.max(cuadrado, elevado);
alert("el valor mas grande es " + maximo);