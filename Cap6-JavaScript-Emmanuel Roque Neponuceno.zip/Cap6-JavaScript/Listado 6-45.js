//Iterando sobre los valores de un array
var total = 0;
var array = [1,2,3,4,5];
for (var f = 0; f < 5; f++) {
  total += array[f];
}
alert("El total es: " + total);
