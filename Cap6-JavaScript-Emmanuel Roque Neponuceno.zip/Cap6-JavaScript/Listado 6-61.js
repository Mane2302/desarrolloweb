//Ejecutando funciones anónimas
var mivalor = function (valor) {
  valor = valor * 2;
  return valor;
}(35);
alert('El valor es: ' + mivalor);