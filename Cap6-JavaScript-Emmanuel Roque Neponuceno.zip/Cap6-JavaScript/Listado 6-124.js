//Creando un objeto Date
var hoy = new Date();
var ano = hoy.getFullYear();
alert("Estamos en el año " + ano);
