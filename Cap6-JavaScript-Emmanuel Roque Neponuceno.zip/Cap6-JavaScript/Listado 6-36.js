//Comprobando una condición con if
var mivariable = 9;
if (mivariable < 10) {
  alert(mivariable + ' es menor que 10');
}
