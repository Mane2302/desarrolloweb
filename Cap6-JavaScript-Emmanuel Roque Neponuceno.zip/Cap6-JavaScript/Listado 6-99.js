//Buscando un texto al comienzo de la cadena
var texto = "Hola mundo";
if (texto.includes("l")) {
    alert("El texto se encuentra la letra 'L'")
}