//Accediendo propiedades usando variables
var nombrePropiedad = "nombre";
var miobjeto = {
  nombre: "Emmanuel",
  "mi edad": 22,
};
alert("Mi nombre edad es: " + miobjeto["mi edad"]);
