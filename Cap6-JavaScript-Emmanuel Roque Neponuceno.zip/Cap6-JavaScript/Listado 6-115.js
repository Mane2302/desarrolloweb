//Eliminando valores de un array
var lista = [12, 5, 80, 34, 5, 6, 7,34];
var removidos = lista.splice(4,3);

alert("Valores restantes: " + lista);
alert("Valores removidos: " + removidos);