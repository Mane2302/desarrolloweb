//Accediendo propiedades usando variables
var nombrePropiedad = "nombre";
var miobjeto = {
  nombre: "Emmanuel",
  edad: 22,
};
alert("Mi nombre es: " + miobjeto[nombrePropiedad]);
