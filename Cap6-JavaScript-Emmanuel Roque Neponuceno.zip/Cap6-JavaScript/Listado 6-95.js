//Referenciando caracteres con índices negativos
var texto = "Hola mundo";
var palabra = texto.substr(-5);
alert(palabra);
