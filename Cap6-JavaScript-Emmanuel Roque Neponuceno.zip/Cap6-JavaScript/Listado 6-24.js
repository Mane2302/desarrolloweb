//Generando nuevas líneas de texto
var mitexto ='\"Draco dormiens nunquam titillandus (Nunca le hagas cosquillas a un dragón dormido)\" \r\n';
mitexto = mitexto + '(Lema de Hogwarts)';
alert(mitexto);