//Declarando una variable booleana
var valido = true;
alert(valido);