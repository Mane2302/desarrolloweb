//Comprobando un valor con la instrucción switch
var mivariable = 105;

switch (mivariable) {
  case 2:
    alert('El número es 2');
    break;

  case 5:
    alert('El número es 5');
    break;
  case 10:
    alert('El número es 10');
    break;
  default:
    alert('El número es: ' + mivariable);
}