//Buscando un texto al comienzo de la cadena
var lista = [1, 2, 3, 4, 5];
var mensaje = lista.join("_");
alert(mensaje);