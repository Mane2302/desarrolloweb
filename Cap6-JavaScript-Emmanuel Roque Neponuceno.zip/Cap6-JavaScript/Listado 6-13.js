//Controlando la precedencia en la operación
var minumero = 67;
var tunumero = minumero * (2 + 6); //536
alert(tunumero);