//Buscando múltiples valores en un array
var lista = [12, 5, 80, 34, 5, 6, 7];
var listanueva = lista.concat([100, 400, 44])
alert(listanueva);