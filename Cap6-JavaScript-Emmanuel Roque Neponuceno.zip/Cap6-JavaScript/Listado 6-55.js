//Llamando a la misma función con diferentes valores
function mifuncion(valor) {
  alert(valor);
}
mifuncion(500);
mifuncion(1000);