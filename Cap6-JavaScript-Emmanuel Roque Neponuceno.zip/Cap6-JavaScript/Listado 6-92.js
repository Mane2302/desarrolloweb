//Convirtiendo los caracteres de una cadena en letras mayúsculas
var texto = "Hola mundo";
texto = texto.toUpperCase();
alert(texto);
