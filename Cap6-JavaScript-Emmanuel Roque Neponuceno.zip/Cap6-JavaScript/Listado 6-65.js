//Creando objetos
var miobjeto = {
  nombre: "Emmanuel",
  edad: 22,
};
