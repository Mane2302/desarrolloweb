//Copiando caracteres entre dos índices
var texto = "Hola mundo";
var palabra = texto.substring(5,7);
alert(palabra);
