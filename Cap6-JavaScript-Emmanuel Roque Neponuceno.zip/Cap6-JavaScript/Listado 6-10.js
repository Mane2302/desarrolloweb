var minumero = 67;
var tunumero = minumero;
alert(tunumero);