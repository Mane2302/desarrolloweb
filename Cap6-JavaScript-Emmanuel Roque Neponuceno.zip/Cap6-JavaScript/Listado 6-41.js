// Usando cadenas de caracteres como condiciones
var nombre = 'Emmanuel';
if (nombre) {
  alert(nombre + ' Tiene el permiso')
}

var nombre = '';
if (nombre) {
  alert(nombre + ' Tiene el permiso')
}