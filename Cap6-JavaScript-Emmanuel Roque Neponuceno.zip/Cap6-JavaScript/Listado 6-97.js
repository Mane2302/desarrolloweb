//Copiando caracteres entre dos índices
var texto = "Hola mundo";
var palabra = texto.split(" ");
alert(palabra[0] + " / " + palabra[1]);
