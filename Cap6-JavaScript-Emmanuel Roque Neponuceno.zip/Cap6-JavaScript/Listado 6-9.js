var minumero = 67;
minumero = 22;
alert(minumero);