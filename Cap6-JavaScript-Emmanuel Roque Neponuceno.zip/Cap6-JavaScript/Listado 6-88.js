//Contando la cantidad de caracteres en una cadena
var texto = "Hola mundo";
var mensaje = "El texto tiene " + texto.length + " caracteres";
alert(mensaje);