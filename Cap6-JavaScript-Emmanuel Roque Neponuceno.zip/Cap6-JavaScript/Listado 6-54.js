//Enviando un valor a una función
function mifuncion(valor) {
  alert(valor);
}
mifuncion(500);