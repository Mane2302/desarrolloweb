//Creando números a partir de cadenas de caracteres
var valor = new Number("5");
alert(valor);