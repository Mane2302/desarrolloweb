//Incrementando una fecha
var hoy = new Date();
alert(hoy);
hoy.setDate(hoy.getDate() + 30);
alert(hoy);
