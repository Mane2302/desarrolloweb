//Almacenando diferentes tipos de valores
var miarray = ['Rojo', 9.75, 'Siuu', 'Azul'];
alert(miarray); //All