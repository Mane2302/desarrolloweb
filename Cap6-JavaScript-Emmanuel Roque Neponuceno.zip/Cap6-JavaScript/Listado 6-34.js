//Asignando un array vacío como el valor de otro array
var miarray = [[1,2],[3,4],[5,6]];
miarray[2] = []
alert(miarray[2][1]); //undefined