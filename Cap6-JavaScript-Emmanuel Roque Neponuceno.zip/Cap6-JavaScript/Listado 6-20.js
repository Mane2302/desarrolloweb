//Concatenando texto
var mitexto = 'Emmanuel';
mitexto = 'Mi nombre es ' + mitexto;
alert(mitexto);