//Trabajando con los valores del array
var miarray = [3, 5];
miarray[0] = miarray[0] * 5;
alert(miarray[0]); //15