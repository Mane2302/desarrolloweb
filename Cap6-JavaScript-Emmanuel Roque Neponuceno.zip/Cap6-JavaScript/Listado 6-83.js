//Creando números con un constructor
var valor = new Number(5);
alert(valor);