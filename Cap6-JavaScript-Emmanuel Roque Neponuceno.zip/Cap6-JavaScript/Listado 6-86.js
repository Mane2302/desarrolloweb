//Creando un array con un constructor
var lista = new Array(1, 2, 3, 4, 5);
alert(lista);
