//Buscando un texto al comienzo de la cadena
var lista = [1, 2, 3, 4, 5];
var indice = lista.indexOf(5);
alert("El valor " + lista[indice] + " se encuentra en el índice " +
indice);