//Creando arrays Mostrando un valor
var miarray = ['Rojo', 'Verde', 'Amarillo', 'Azul'];
alert(miarray[3]); //Azul