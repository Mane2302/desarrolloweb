// Usando valores booleanos como condiciones
var soltero = false;
var edad = 18;
if (edad>=18 && soltero) { //soltero no se iguala a true ya que no es  necesario por &&
  alert('El el solicitante puede casarse!!!');
}
else{
  alert('El solicitante no puede casarse');
}