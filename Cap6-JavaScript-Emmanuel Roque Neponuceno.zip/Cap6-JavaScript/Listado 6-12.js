//Realizando operaciones complejas
var minumero = 67;
var tunumero = minumero * 2 + 6; //140
alert(tunumero);