//Declarando funciones
function Mostrarmensaje() {
    alert('Estoy llamando a una función');
}
Mostrarmensaje();