//Enviando el valor de una variable a una función
var contador = 200;
function mifuncion(valor) {
  alert(valor);
}
mifuncion(contador);