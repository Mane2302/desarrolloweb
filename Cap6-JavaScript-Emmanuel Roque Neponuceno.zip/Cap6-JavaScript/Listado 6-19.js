//Concatenando texto
var mitexto = 'Mi nombre es ';
mitexto = mitexto + 'Emmanuel';
alert(mitexto);