var minumero = 67;
alert(minumero);