//Realizando una operación con el valor almacenado en una variable
var minumero = 67;
var tunumero = minumero + 3;
alert(tunumero);