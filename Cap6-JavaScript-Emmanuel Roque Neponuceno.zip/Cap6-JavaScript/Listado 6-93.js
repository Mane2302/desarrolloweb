//Copiando un grupo de caracteres
var texto = "Hola mundo";
var palabra = texto.substring(0, 4);
alert(palabra);
