//Escapando caracteres
var mitexto = 'El mago \"Harry Potter\" es el elegido.';
alert(mitexto);