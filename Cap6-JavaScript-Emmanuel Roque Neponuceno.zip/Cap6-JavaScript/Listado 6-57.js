//Enviando múltiples valores a la función
var contador = 200;
var items = 20;
function mifuncion(valor1, valor2) {
  var total = valor1 + valor2;
  alert(total);
}
mifuncion(contador, items);