//Iterando sobre el array
var lista = [1, 2, 3, 4, 5];
var total=0;
for(f=0; f<lista.length;f++){
    total += lista[f]
}
alert("El total es " + total);