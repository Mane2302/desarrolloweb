//Incrementando el valor de una variable
var minumero = 0;
minumero++;
alert(minumero);