UPDATE `#__scheduler_tasks` SET `title` = 'Delete Action Logs' WHERE `type` = 'delete.actionlogs' AND `title` = 'DeleteActionLogs';
UPDATE `#__scheduler_tasks` SET `title` = 'Privacy Consent' WHERE `type` = 'privacy.consent' AND `title` = 'PrivacyConsent';
UPDATE `#__scheduler_tasks` SET `title` = 'Rotate Logs' WHERE `type` = 'rotation.logs' AND `title` = 'RotateLogs';
UPDATE `#__scheduler_tasks` SET `title` = 'Session GC' WHERE `type` = 'session.gc' AND `title` = 'SessionGC';
UPDATE `#__scheduler_tasks` SET `title` = 'Update Notification' WHERE `type` = 'update.notification' AND `title` = 'UpdateNotification';
